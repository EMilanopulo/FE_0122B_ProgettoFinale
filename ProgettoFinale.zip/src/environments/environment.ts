// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  pathApi: 'http://epicode.online/epicodebeservice_v2',
  adminToken: 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY1MDYyOTMzNiwiZXhwIjoxNjUyNzc2ODE5fQ.gGBGelgEVQSXRmOYj2ZqsXKkVN1RF-LnNEyQbduLrycuyZWcb8kvhDDhHpRIcPI_wJnBPVyzUYYr1w-r1pvP3w',
  adminTenant: 'fe_0122b'
};

