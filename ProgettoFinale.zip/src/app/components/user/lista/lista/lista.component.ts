import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/_services/auth.service';
import { User } from 'src/app/_models/user';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';


@Component({
	selector: 'app-lista',
	templateUrl: './lista.component.html',
	styleUrls: ['./lista.component.scss']
})
export class ListaComponent implements OnInit {

  page!: number;
	pageSize!: number;
  form!: FormGroup;
	response: any;
	users!: Array<User>;
	constructor(private authService: AuthService, private fb: FormBuilder) { }

	ngOnInit() {
		this.Carica();
    this.InizializzaForm();
	}

  Carica() {
		this.authService.GetAll(0).subscribe(c => {
			console.log(c);
			this.response = c;
			this.users = c.content;
		});
	}

  InizializzaForm() {
    this.form = this.fb.group({
      Cerca: new FormControl(),
    });
  }

  CambiaPagina(p: number) {
		this.authService.GetAll(p).subscribe(res => {
			this.response = res;
			this.users = res.content;
		});
	}

  counter(i: number) {
		return new Array(i);
	}

}
